export const processImage = jest.fn(() => Promise.resolve(new Blob()));
