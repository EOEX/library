export const refreshApex = jest.fn(() => Promise.resolve());
