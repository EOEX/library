import { createTestWireAdapter } from '@salesforce/wire-service-jest-util';

// Mock getContactList wire adapter
export default createTestWireAdapter();
