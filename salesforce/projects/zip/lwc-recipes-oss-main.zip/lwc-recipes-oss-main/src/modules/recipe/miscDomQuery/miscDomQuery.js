import { LightningElement } from 'lwc';

export default class MiscDomQuery extends LightningElement {
    selection;

    handleCheckboxChange() {
        // Query the DOM
        const checked = Array.from(this.template.querySelectorAll('ui-input'))
            // Filter to only checked items
            .filter((element) => element.checked)
            // Map to their labels
            .map((element) => element.label);
        this.selection = checked.join(', ');
    }
}
