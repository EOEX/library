import { LightningElement } from 'lwc';

export default class LightDomStylesChild extends LightningElement {
    static renderMode = 'light';
}
