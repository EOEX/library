import { LightningElement } from 'lwc';

export default class LightDomStyles extends LightningElement {}
