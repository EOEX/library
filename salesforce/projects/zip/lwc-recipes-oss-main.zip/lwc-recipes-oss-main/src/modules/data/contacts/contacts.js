export const contacts = [
    {
        Id: '0031700000pJRRSAA4',
        Name: 'Amy Taylor',
        Title: 'VP of Engineering',
        Phone: '4152568563',
        Email: 'amy@demo.net',
        Picture: '/assets/images/demo/amy_taylor.jpg'
    },
    {
        Id: '0031700000pJRRTAA4',
        Name: 'Michael Jones',
        Title: 'VP of Sales',
        Phone: '4158526633',
        Email: 'michael@demo.net',
        Picture: '/assets/images/demo/michael_jones.jpg'
    },
    {
        Id: '0031700000pJRRUAA4',
        Name: 'Jennifer Wu',
        Title: 'CEO',
        Phone: '4158521463',
        Email: 'jennifer@demo.net',
        Picture: '/assets/images/demo/jennifer_wu.jpg'
    },
    {
        Id: '0031700000pJRRVAA4',
        Name: 'Anup Gupta',
        Title: 'VP of Products',
        Phone: '4158526398',
        Email: 'anup@demo.net',
        Picture: '/assets/images/demo/anup_gupta.jpg'
    },
    {
        Id: '0031700000pJRRWAA4',
        Name: 'Caroline Kingsley',
        Title: 'VP of Technology',
        Phone: '4158753654',
        Email: 'caroline@demo.net',
        Picture: '/assets/images/demo/caroline_kingsley.jpg'
    },
    {
        Id: '0031700000pJRRXAA4',
        Name: 'Jonathan Bradley',
        Title: 'VP of Opearations',
        Phone: '4158885522',
        Email: 'jonathan@demo.net',
        Picture: '/assets/images/demo/jonathan_bradley.jpg'
    }
];
