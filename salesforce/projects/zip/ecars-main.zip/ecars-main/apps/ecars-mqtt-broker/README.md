# ecars-mqtt-broker

MQTT Broker with WebSockets Support

## Run locally

```
npm install
node server.js
```
