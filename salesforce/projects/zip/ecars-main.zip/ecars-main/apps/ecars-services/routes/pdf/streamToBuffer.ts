import { ReadStream } from 'fs';

export default async function streamToBuffer(
    stream: ReadStream
): Promise<Buffer> {
    return new Promise((resolve, reject) => {
        const chunks = [];
        stream.on('data', (chunk) => chunks.push(chunk));
        stream.on('end', () => resolve(Buffer.concat(chunks)));
        stream.on('error', (error) => reject(error));
    });
}
