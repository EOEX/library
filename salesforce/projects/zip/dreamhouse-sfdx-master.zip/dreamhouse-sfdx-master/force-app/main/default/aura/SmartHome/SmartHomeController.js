({
    myAction: function () {}
});
