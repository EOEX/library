# QuiddityRecipes Class

Demonstrates the use and functionaly of Quiddity

**Group** Quiddity Recipes

## Methods
### `demonstrateGetQuiddity()`

demonstrates the code needed to get the current requests 
Quiddity value.

#### Signature
```apex
public static Quiddity demonstrateGetQuiddity()
```

#### Return Type
**Quiddity**