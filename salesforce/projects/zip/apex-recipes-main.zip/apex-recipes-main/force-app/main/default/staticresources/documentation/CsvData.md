# CsvData Class

## Fields
### `FirstName`

#### Signature
```apex
public FirstName
```

#### Type
String

---

### `LastName`

#### Signature
```apex
public LastName
```

#### Type
String

---

### `Email`

#### Signature
```apex
public Email
```

#### Type
String