# SchemaRecipes Class

Responsible for showing how to use schema and schema tokens

**Group** Schema Recipes

## Methods
### `schemaTokenRecipe()`

demonstrates how to use a field token for schema access

#### Signature
```apex
public void schemaTokenRecipe()
```

#### Return Type
**void**