import { LightningElement, api } from 'lwc';

export default class FormattedDocsViewer extends LightningElement {
    @api recipeName = ''; // = 'SOQLRecipes';
}
