import { LightningElement } from 'lwc';

export default class RecipeTreeView extends LightningElement {}
