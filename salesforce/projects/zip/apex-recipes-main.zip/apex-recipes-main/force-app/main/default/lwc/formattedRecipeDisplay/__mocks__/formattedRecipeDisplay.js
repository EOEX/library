import { LightningElement, api } from 'lwc';

export default class FormattedRecipeDisplay extends LightningElement {
    @api recipeName = ''; // = 'SOQLRecipes';
}
