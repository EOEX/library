# LogSeverity Enum

A top-level severity enum for Log, and LogMessage to use.

**Group** Shared Code

## Values
| Value | Description |
|-------|-------------|
| DEBUG |  |
| INFO |  |
| WARN |  |
| ERROR |  |