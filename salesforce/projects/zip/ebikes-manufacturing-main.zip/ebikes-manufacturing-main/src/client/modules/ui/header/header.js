import { LightningElement } from 'lwc';

export default class Header extends LightningElement {}
