import { LightningElement } from 'lwc';

export default class PageBlocksWrapper extends LightningElement {}
