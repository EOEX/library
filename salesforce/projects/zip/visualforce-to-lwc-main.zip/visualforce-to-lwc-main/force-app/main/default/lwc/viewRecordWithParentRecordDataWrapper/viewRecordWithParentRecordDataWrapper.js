import { LightningElement, api } from 'lwc';

export default class ViewRecordWithParentRecordDataWrapper extends LightningElement {
    @api recordId;
}
