import { LightningElement } from 'lwc';

export default class PanelGridWrapper extends LightningElement {}
