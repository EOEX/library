import { LightningElement } from 'lwc';

export default class EditableListWrapper extends LightningElement {}
