import { LightningElement } from 'lwc';

export default class ListWithParentRecordData extends LightningElement {}
