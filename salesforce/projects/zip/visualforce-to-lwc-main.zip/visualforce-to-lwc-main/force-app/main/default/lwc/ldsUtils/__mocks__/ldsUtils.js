export function reduceErrors() {
    return '';
}
