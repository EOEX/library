import { LightningElement, api } from 'lwc';

export default class EditRecordWrapper extends LightningElement {
    @api recordId;
}
