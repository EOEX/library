import { LightningElement } from 'lwc';

export default class EditableList extends LightningElement {}
