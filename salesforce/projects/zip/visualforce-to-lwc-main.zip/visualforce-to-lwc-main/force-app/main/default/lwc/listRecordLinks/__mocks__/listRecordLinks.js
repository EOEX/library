import { LightningElement } from 'lwc';

export default class ListRecordLinks extends LightningElement {}
