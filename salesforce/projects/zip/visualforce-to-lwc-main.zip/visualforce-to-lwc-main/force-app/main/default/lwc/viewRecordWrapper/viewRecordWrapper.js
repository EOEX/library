import { LightningElement, api } from 'lwc';

export default class ViewRecordWrapper extends LightningElement {
    @api recordId;
}
