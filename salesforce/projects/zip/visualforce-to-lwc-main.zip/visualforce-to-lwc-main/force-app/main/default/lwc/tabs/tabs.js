import { LightningElement } from 'lwc';

export default class Tabs extends LightningElement {}
