import { LightningElement } from 'lwc';

export default class PanelGrid extends LightningElement {}
