import { LightningElement } from 'lwc';

export default class BeforeRenderHookWrapper extends LightningElement {}
