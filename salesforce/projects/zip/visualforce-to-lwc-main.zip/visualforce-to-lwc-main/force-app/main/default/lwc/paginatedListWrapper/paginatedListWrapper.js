import { LightningElement } from 'lwc';

export default class PaginatedListWrapper extends LightningElement {}
