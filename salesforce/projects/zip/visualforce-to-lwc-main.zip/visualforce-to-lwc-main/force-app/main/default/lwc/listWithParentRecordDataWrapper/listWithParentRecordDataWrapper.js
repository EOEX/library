import { LightningElement } from 'lwc';

export default class ListWithParentRecordDataWrapper extends LightningElement {}
