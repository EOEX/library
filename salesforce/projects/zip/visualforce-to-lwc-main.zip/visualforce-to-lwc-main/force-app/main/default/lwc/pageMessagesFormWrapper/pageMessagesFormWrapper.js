import { LightningElement } from 'lwc';

export default class PageMessagesFormWrapper extends LightningElement {}
