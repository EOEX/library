import { LightningElement } from 'lwc';

export default class PageMessagesDataRetrievalWrapper extends LightningElement {}
