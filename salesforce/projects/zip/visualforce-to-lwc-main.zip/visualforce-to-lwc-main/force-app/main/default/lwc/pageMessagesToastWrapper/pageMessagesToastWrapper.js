import { LightningElement } from 'lwc';

export default class PageMessagesToastWrapper extends LightningElement {}
