import { LightningElement } from 'lwc';

export default class AfterRenderHookWrapper extends LightningElement {}
