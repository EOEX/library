import { LightningElement } from 'lwc';

export default class CreateMixedRecordsWireFunctionsWrapper extends LightningElement {}
