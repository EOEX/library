import { LightningElement } from 'lwc';

export default class ListRecordLinksWrapper extends LightningElement {}
