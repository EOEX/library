import { LightningElement } from 'lwc';

export default class PageMessagesDataRetrieval extends LightningElement {}
