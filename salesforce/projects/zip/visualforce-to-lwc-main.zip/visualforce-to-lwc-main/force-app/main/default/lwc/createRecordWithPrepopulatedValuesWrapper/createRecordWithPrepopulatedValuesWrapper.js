import { LightningElement } from 'lwc';

export default class CreateRecordWithPrepopulatedValuesWrapper extends LightningElement {}
