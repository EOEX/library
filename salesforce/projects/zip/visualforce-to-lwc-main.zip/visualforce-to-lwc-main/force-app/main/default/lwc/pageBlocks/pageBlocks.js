import { LightningElement } from 'lwc';

export default class PageBlocks extends LightningElement {
    activeSections = ['A', 'B'];
}
