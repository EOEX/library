import { LightningElement } from 'lwc';

export default class BindingWrapper extends LightningElement {}
