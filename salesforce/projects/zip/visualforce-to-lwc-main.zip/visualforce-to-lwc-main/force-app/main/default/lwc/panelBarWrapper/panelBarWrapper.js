import { LightningElement } from 'lwc';

export default class PanelBarWrapper extends LightningElement {}
