import { LightningElement } from 'lwc';

export default class ListInfiniteScrollingWrapper extends LightningElement {}
