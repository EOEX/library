import { registerSa11yMatcher } from '@sa11y/jest';

registerSa11yMatcher();
